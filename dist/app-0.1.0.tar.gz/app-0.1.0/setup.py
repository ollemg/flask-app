# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['app', 'app.ext.admin', 'app.ext.config', 'app.ext.site', 'app.ext.toolbar']

package_data = \
{'': ['*'], 'app': ['templates/*']}

install_requires = \
['Flask-Admin>=1.5.8,<2.0.0',
 'Flask-DebugToolbar>=0.11.0,<0.12.0',
 'Flask>=2.0.1,<3.0.0',
 'black>=21.9b0,<22.0',
 'flake8>=3.9.2,<4.0.0',
 'gunicorn>=20.1.0,<21.0.0',
 'ipdb>=0.13.9,<0.14.0',
 'ipython>=7.27.0,<8.0.0',
 'isort>=5.9.3,<6.0.0']

setup_kwargs = {
    'name': 'app',
    'version': '0.1.0',
    'description': 'flask app example',
    'long_description': None,
    'author': 'Gabriel Barbosa',
    'author_email': 'gabrielmello808@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
